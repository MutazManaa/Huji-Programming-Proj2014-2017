/**
 * specifies the supported types of tokens
 */
public enum TokenType {
    KEYWORD, SYMBOL, IDENTIFIER, INT_CONST, STRING_CONST
}
