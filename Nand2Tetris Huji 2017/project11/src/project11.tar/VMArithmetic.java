/**represnt arthmitic command*/
public enum VMArithmetic {
	ADD, SUB, NEG, EQ, GT, LT, AND, OR, NOT, MULT, DIVIDE
}
