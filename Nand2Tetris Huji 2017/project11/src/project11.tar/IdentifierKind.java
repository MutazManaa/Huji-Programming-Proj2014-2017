/**represent identifier */
public enum IdentifierKind {
	STATIC, FIELD, ARG, VAR, NONE

}
