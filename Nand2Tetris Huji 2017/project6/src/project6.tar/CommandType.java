/*comand type represent the command types of the parser instructions*/
public enum CommandType {
    A_COMMAND,C_COMMAND,L_COMMAND
}
